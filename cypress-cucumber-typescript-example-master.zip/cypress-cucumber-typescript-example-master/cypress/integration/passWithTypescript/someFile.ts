export const pass = (somethingToSay: String): void => {
    console.log("HELLO", somethingToSay)
}
